function Footer(){
    return (
        <footer className="footer"></footer>
    )
}
export default Footer;