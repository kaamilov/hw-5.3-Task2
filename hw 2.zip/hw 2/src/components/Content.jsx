function Content(){
    return (
        <section className="section"></section>
    )
}
export default Content;